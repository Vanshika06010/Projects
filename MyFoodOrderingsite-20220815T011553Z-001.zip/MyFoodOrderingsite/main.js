localStorage.setItem("isAddress", "false");
///Sliding Menu --- STARTS ----
let isOpen = false;

let slideMenu = function() {
        let getSidebar = document.querySelector(".nav-sidebar");
        let getSidebarUL = document.querySelector(".nav-sidebar ul");
        let getSidebarTitle = document.querySelector(".nav-sidebar span");
        let getSidebarLinks = document.querySelectorAll(".nav-sidebar a");



        if (isOpen === false) {
            getSidebarUL.style.visibility = "visible";
            getSidebar.style.width = "272px"
            getSidebarTitle.style.opacity = "0.5"

            let arrayLength = getSidebarLinks.length;
            for (var i = 0; i < arrayLength; i++) {
                getSidebarLinks[i].style.opacity = "1";
            }

            isOpen = true;
        } else if (isOpen === true) {

            getSidebar.style.width = "60px"
            getSidebarTitle.style.opacity = "0"

            let arrayLength = getSidebarLinks.length;
            for (var i = 0; i < arrayLength; i++) {
                getSidebarLinks[i].style.opacity = "0";
            }
            getSidebarUL.style.visibility = "hidden";
            isOpen = false;
        }
    }
    ///Sliding Menu --- ENDS ----
    ///Save() saves address to local storage. --- STARTS ---
function save() {
    var address = [];
    var firstLine, secondLine, province, country, postalCode, phoneNumber;
    firstLine = document.forms[0].elements[0].value;
    secondLine = document.forms[0].elements[1].value;
    province = document.forms[0].elements[2].value;
    country = document.forms[0].elements[3].value;
    postalCode = document.forms[0].elements[4].value;
    phoneNumber = document.forms[0].elements[5].value;

    console.log(firstLine);
    console.log(secondLine);
    console.log(province);
    console.log(country);
    console.log(postalCode);
    console.log(phoneNumber);

    address = [firstLine, secondLine, province, country, postalCode, phoneNumber];
    localStorage.setItem("address", JSON.stringify(address));
    localStorage.setItem("isAddress", "true");
}
///Save() saves address to local storage. --- ENDS ---
///Resturant object --- STARTS ---
function resturants(name, url, type, items) {
    this.name = name;
    this.url = url;
    this.type = type;
    this.items = items;
}
///Resturant object --- ENDS ---
///Items object --- STARTS ---
function item(name, restName, type, url, price) {
    this.name = name;
    this.restName = restName;
    this.type = type;
    this.url = url;
    this.price = price;
}
///Items object --- ENDS ---
///Populating itmes list --- STARTS ---
var count = 0;
var items = [];
items[count] = new item("Hamburger", "Burger Queen", "fast food", "hamBurger.html", 9.99);
count++;
items[count] = new item("Poutine", "EggDonalds", "fast food", "EggDonalds-Poutine.html", 4.99);
count++;
items[count] = new item("BeefStake", "Deg", "steak", "Deg-BeefSteak.html", 30.99);
count++;
items[count] = new item("AmigosPizza", "Amigos", "pizza", "AmigosPizza-pizza.html", 24.99);
count++;
items[count] = new item("bnwSandwich", "bnw", "fast food", "bnw-sandwich.html", 4.99);
count++;
items[count] = new item("burqerQueen-poutine", "burgerQueen", "fast food", "burgerQueen-poutine.html", 7.99);
count++;
items[count] = new item("wayFuture-Burger", "Way Future", "fast food", "hamburger.html", 15.99);
///Populating itmes list --- ENDS ---
///AddItems(nameOfItem) adds the name of the item to the ordered list. --- STARTS --- 
function addItems(params) {
    var yourCurrentOrder = [];
    var toBeAdded;
    if (params === "hamBurger") {
        toBeAdded = new item(
            "Hamburger",
            "EggDonalds",
            "fast food",
            "hamBurger.html",
            9.99
        );
    } else if (params === "Poutine") {
        toBeAdded = new item(
            "Poutine",
            "EggDonalds",
            "fast food",
            "EggDonalds-Poutine.html",
            4.99
        );
    } else if (params === "MuttonStake") {
        toBeAdded = new item(
            "MuttonStake",
            "Deg",
            "steak",
            "Deg-BeefSteak.html",
            30.99
        );
    } else if (params === "AmigosPizza") {
        toBeAdded = new item(
            "AmigosPizza",
            "Amigos",
            "Pizza",
            "AmigosPizza-pizza.html",
            24.99
        );
    } else if (params === "bnw-sandwich") {
        toBeAdded = new item(
            "bnw-sandwich",
            "bnw",
            "sandwich",
            "bnw-sandwich.html",
            24.99
        );
    } else if (params === "burqerQueen-poutine") {
        toBeAdded = new item(
            "burqerQueen-poutine",
            "burgerQueen",
            "poutine",
            "burgerQueen-poutine.html",
            7.99
        );
    } else if (params === "wayfuture-Hamburger") {
        toBeAdded = new item(
            "WayFuture-Hamburger",
            "Way Future",
            "Hamburger",
            "wayfuture-hamburger.html",
            7.99
        );
    }
    if (localStorage.item) {
        yourCurrentOrder = JSON.parse(localStorage.item);
    }
    yourCurrentOrder.push(toBeAdded);
    localStorage.setItem("item", JSON.stringify(yourCurrentOrder));
}
///AddItems(nameOfItem) adds the name of the item to the ordered list. --- ENDS --- 

if (localStorage.item) {
    var lengthR = JSON.parse(localStorage.item).length;
    var text = '<p class="toBeSorted"><table>' +
        "<tr>" +
        "<th>Resturants Name</th>" +
        "<th>Item</th>" +
        "<th>Price</th>" +
        "</tr>";

    for (i = 0; i < lengthR; i++) {
        var name = JSON.parse(localStorage.item)[i].name;
        var url = JSON.parse(localStorage.item)[i].url;
        var price = JSON.parse(localStorage.item)[i].price;
        var resto = JSON.parse(localStorage.item)[i].restName;
        text +=
            "<tr>" +
            "<td>" + resto + "</td>" +
            '<td><a href="' + url + '">' + name + '</a></td>' +
            '<td>$ ' + price + '</td>' +
            '</tr>';
    }
    text += '</table></p>';


    if (document.getElementById("ordered")) {
        document.getElementById("ordered").innerHTML = text;
    }

    function removeAll() {
        if (localStorage) {
            localStorage.clear();
            location.reload();
        }
    }
}

function search() {
    var searchFor = "EMPTY";
    var result = [];
    if (document.getElementById("search").value) {
        searchFor = document.getElementById("search").value;
        for (i = 0; i < items.length; i++) {
            if (items[i].name === searchFor) {
                result.push(items[i]);

            }
        }
        for (i = 0; i < items.length; i++) {
            if (items[i].restName === searchFor) {
                result.push(items[i]);
            }
        }
        for (i = 0; i < items.length; i++) {
            if (items[i].type === searchFor) {
                result.push(items[i]);
            }
        }
        if (!result) {
            document.getElementById("quickSearchResults").innerHTML = "NO RESULTS FOUND";
        } else {
            localStorage.setItem("searchList", JSON.stringify(result));
            var text = '<p class="toBeSorted"><table>' +
                "<tr>" +
                "<th>Resturants Name</th>" +
                "<th>Item</th>" +
                "<th>Price</th>" +
                "</tr>";
            for (i = 0; i < result.length; i++) {
                var name = result[i].name;
                var url = result[i].url;
                var price = result[i].price;
                var resto = result[i].restName;
                text +=
                    "<tr>" +
                    "<td>" + resto + "</td>" +
                    '<td><a href="' + url + '">' + name + '</a></td>' +
                    '<td>$ ' + price + '</td>' +
                    '</tr>';
            }
            text += '</table></p>';
            if (document.getElementById("quickSearchResults")) {
                document.getElementById("quickSearchResults").innerHTML = text;
            }
        }
    }
}

function sort() {
    if (localStorage.searchList) {
        var list = JSON.parse(localStorage.searchList);
    }
    if (!list) {
        document.getElementById("quickSearchResults").innerHTML = "NO RESULTS FOUND";
    } else {
        var text = '<p class="toBeSorted"><table>' +
            "<tr>" +
            "<th>Resturants Name</th>" +
            "<th>Item</th>" +
            "<th>Price</th>" +
            "</tr>";
        for (i = 0; i < list.length; i++) {
            var name = list[i].name;
            var url = list[i].url;
            var price = list[i].price;
            var resto = list[i].restName;
            text +=
                "<tr>" +
                "<td>" + resto + "</td>" +
                '<td><a href="' + url + '">' + name + '</a></td>' +
                '<td>$ ' + price + '</td>' +
                '</tr>';
        }
        text += '</table></p>';
        if (document.getElementById("quickSearchResults")) {
            document.getElementById("quickSearchResults").innerHTML = text;
        }
    }
}